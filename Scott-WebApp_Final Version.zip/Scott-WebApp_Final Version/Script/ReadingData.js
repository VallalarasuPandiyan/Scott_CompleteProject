﻿

function DataDrivenUsingDDT ()
{
DDT.ExcelDriver("D:\\Customer\\Scott AirForce base\\TestComplete Projects\\Scott-WebApp\\WebOrder-UserDetails.xlsx", "Admin")
DDT.ExcelDriver("D:\\Customer\\Scott AirForce base\\TestComplete Projects\\Scott-WebApp\\WebOrder-UserDetails.xlsx", "Privliage")

while (!DDT.CurrentDriver.EOF())
  {
    
   

    WebOrders_Username = DDT.CurrentDriver.Value(0)
    WebORders_PAssword =DDT.CurrentDriver.
    

    
    
    
    
    
    
    
    
    
    
        
    DDT.CurrentDriver.Next();
  }
  DDT.CloseDriver(DDT.CurrentDriver.Name);
}

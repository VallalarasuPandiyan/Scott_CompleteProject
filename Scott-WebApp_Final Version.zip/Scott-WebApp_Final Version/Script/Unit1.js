﻿

function LaunchmyApp(){
  
  
Browsers.Item("iexplore").Run()
Browsers.Item("iexplore").Navigate("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx")

}




//
//function zipcodeupdate ()
//{
//  Aliases.browser.pageDefault.formAspnetform.table.cell.panel2.tableFmworder.cell.textboxTextbox5.SetText(asdfsd)
//  
//
//  
//
//  }
//
//function Variabless() {
//  
//
//
// Log.message (ProjectSuite.Variables.PSVariable)
//  Log.message (Project.Variables.PrVariable)
//  Log.Message(KeywordTests.KeywordUnit.Variables)
//  
//  
//  Project.Path + 

//}
  
 




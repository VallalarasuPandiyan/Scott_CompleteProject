﻿//USEUNIT CreateOrders
function KeywordUnit()
{
  var OrderWebAppURL, Var1, WebOrderPwd, Var4, KTVariable, TimeoutValue;
  OrderWebAppURL = "http://secure.smartbearsoftware.com/samples/TestComplete11/WebOrders/default.aspx";
  Var1 = "Tester";
  WebOrderPwd = null;
  Var4 = "";
  KTVariable = "KEywordTestVariable";
  //Launches the specified browser and opens the specified URL in it.
  Browsers.Item(btIExplorer).Run(OrderWebAppURL, 5);
  //Enters text in the text box.
  Aliases.browser.WebOrderPage.Login_UserName.SetText("Tester");
  //Enters text in the text box.
  Aliases.browser.WebOrderPage.Login_Password.SetText(WebOrderPwd);
  //Performs a single click on the specified button.
  Aliases.browser.WebOrderPage.Login_Submit.ClickButton();
  //Posts an information message to the test log.
  Log.Message("Login successfully", "");
  //Simulates a left-button single click in a window or control as specified (relative position, shift keys).
  Aliases.browser.OrderSummaryPage.CreateOrder.Click();
  //Runs a script routine.
  CreateOrders();
  //Closes the process by sending the close command to its main window.
  Sys.Process("EXCEL").Close();
  TimeoutValue = Options.Run.Timeout;
  Options.Run.Timeout = 15000;
  //Simulates a left-button single click in a window or control as specified (relative position, shift keys).
  Aliases.browser.OrderSummaryPage.CreateOrder.Click();
  Options.Run.Timeout = TimeoutValue;
  if(Aliases.browser.OrderSummaryPage.CreateOrder.Exists);
  //Simulates a left-button single click in a window or control as specified (relative position, shift keys).
  Aliases.browser.OrderSummaryPage.CreateOrder.Click();
  //Delays the test execution for the specified time period.
  Delay(517);
  //Simulates a left-button single click in a window or control as specified (relative position, shift keys).
  Aliases.browser.OrderSummaryPage.CreateOrder.Click();
}
﻿function Test1()
{
  let browser = Aliases.browser;
  let browserWindow = browser.BrowserWindow;
  browserWindow.Click(534, 66);
  Browsers.Item(btChrome).Navigate("http://192.168.30.63/");
  let page = browser.page1921683063;
  page.Keys("[BS][BS][BS]");
  page.Keys("[BS][BS]");
  browserWindow.Click(1350, 68);
  browser.ToUrl("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx");
  let panel = browser.pageWebOrdersLogin.formAspnetform.panel;
  let textbox = panel.textboxUsername;
  textbox.Click(12, 10);
  textbox.SetText("Tester");
  textbox.Keys("[Tab]");
  panel.passwordboxPassword.SetText("test");
  aqObject.CheckProperty(Aliases.browser.pageWebOrdersLogin.formAspnetform.submitbuttonLogin, "value", cmpEqual, "Login");
  panel.submitbuttonLogin.ClickButton();
  browser.pageDefault.Wait();
  WebTesting.WebAccessibility1.Check();
}

module.exports.Test1 = Test1;
﻿function LaunchmyApp(){
Browsers.Item("chrome").Run()
Browsers.Item("chrome").Navigate("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx")
}



function Login(Uname,Pwd){
Aliases.browser.WebOrderPage.Login_UserName.SetText(Uname)
Aliases.browser.WebOrderPage.Login_Password.SetText(Pwd)
NameMapping.Sys.browser.WebOrderPage.formAspnetform.Login_Submit.ClickButton()
}

function Sample()
{

Login("Uname","Pwd")
}


function CloseApp()
{  
Aliases.browser.Terminate()
}

﻿//
//function Helperobject ()
//{
////StrCmp = aqString.Compare("Valla","valla",false)
////
////if (StrCmp == 0)
////{
////  Log.Message("String Exact Match")
////}
////else
////{
////  Log.Error("Comparision Failed")
////}
//
////Log.message (aqString.Trim(" Test Complete "))
////Log.message (aqString.GetLength("Srrrr"))
////
////DatetimeVar = aqDateTime.
////Log.Message(DatetimeVar)
//
//
////DatetimeVar = aqConvert.
////Log.Message(DatetimeVar)
//
//
////BuiltIn.
//
//aqEnvironment.
//
//aqFile.
//
//aqFileSystem.
//
//aqObject.CallMethod()
//aqObject.CheckProperty(Aliases.browser.OrderSummaryPage.URL, "www.gmail.com", )
//

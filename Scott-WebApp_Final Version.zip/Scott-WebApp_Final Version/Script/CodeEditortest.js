﻿

function MyCode()
{
  Log.Message("Code")
}


function NewCode()
{
  
MyCode()
Log.Error("Intentional")
}
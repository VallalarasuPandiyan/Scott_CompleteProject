﻿//function LaunchmyApp(){
//Browsers.Item("iexplore").Run()
//Browsers.Item("iexplore").Navigate("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx")
//}
//
//
//function D_LaunchmyApp(){
//Browsers.Item("iexplore").Run()
//Browsers.Item("iexplore").Navigate("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx")
//}
//
//function Login(){
//Aliases.browser.WebOrderPage.Login_UserName.SetText(Project.Variables.Username)
//Aliases.browser.WebOrderPage.Login_Password.SetText("test")
//NameMapping.Sys.browser.WebOrderPage.formAspnetform.Login_Submit.ClickButton()
//}
//
//function D_Login(){  
//  Login_UserName = Sys.Browser("iexplore").FindChild("ObjectIdentifier","username",5)
//  Login_UserName.SetText("Tester")
//  Login_Password = Sys.Browser("iexplore").FindChild("ObjectIdentifier","password",5)
//  Login_Password.SetText("test")
//  Login_Submit = Sys.Browser("iexplore").FindChild("ObjectLabel","Login",5)
//  Login_Submit.Click()
//}
//
//function NavigateToOrder()
//{
//Aliases.browser.OrderSummaryPage.CreateOrder.Click()
//}
//
//function D_NavigateToOrder(){
//  
//
//OrderLink = Sys.Browser("iexplore").FindChild(Array("ObjectType","contentText"),Array("Link","Order"),30)
//OrderLink.Click()
//
//
//}
//
//
//function D_NavigateToAllOrder(){
//AllOrdersLink = Sys.Browser("iexplore").FindChild(Array("ObjectType","contentText"),Array("Link","View all Orders"),30)
//AllOrdersLink.Click()
//}
//
//
//
//
//
//function FindFromWebTable(){
//  
//Single_WebTableElement = Sys.Browser("iexplore").FindChild(Array("ObjectType","contentText"),Array("Cell","Paul Brown"),30)
//Log.message (Single_WebTableElement.contentText)
//
//WebTableElement = Sys.Browser("iexplore").FindChild("ObjectIdentifier","orderGrid",30)
//
//
//MyCells = WebTableElement.FindAllChildren("ObjectType","Cell",30)
//
//Log.Message("Total Elements: " + MyCells.length)
//for (let i = 0; i < MyCells.length; i++)
//
//CurrentCellValue = MyCells[i].contentText 
//      Log.Message(MyCells[i].contentText);   
//  }
//  
// 
//  function ValidationText()
//  {   
//    
// // a = "Automation"
// // ValidationCheckpoint = Files.Automation_Introduction_txt.Check("D:\Customer\Scott AirForce base\Automation Introduction.txt")
//   ValidationCheckpoint = Files.Compare("D:\\Customer\\Scott AirForce base\\Automation Introduction New.txt","D:\\Customer\\Scott AirForce base\\Automation Introduction.txt")
//   //Automation_Introduction_txt.Check(a)
// // Check("Automation")
//  Log.Message(ValidationCheckpoint)
//  Files.
//  
//    }
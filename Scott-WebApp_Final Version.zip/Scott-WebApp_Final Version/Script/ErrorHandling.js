﻿function ErrorCheck()

{
try
{
Log.Error("Adfsdf")
}
catch (e)
{

Log.Message(e.description)

}


}











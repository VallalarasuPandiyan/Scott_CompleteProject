﻿function EventControlWeb_OnLogCheckpoint(Sender, LogParams)
{
  


  
}

function EventControlWeb_OnOverlappingWindow(Sender, Window, OverlappingWindow, LogParams)
{  
Popup = Sys.Browser("Chrome").FindChild("Title","Special offers", 30)
BtbYes = Popup.FindChild("Button","Accept", 30)
BtbYes.Click
}

function EventControlWeb_OnUnexpectedWindow(Sender, Window, LogParams)
{
  

  
}

function EventControlWeb_OnStartTest(Sender)
{
 OpenBrowser = Sys.WaitBrowser("Chrome")
 OpenIEbrowser = Sys.WaitBrowser("iexplore")
 OpenEdgeBrowser = Sys.WaitBrowser("Edge")
 OpenExcel = Sys.WaitProcess("EXCEL")
 
 
 if (OpenIEbrowser.Exists)
 {
   OpenIEbrowser.Close()
   Log.Message("Pre-requiestions are set")
   aqUtils.Delay(3000)
   
 }
 else
 {
  Log.Message("Pre-requiestions are set") 
 }

 
 
 if (OpenBrowser.Exists)
 {
   OpenBrowser.Close()
   Log.Message("Pre-requiestions are set")
   aqUtils.Delay(3000)
   
 }
 else
 {
  Log.Message("Pre-requiestions are set") 
 }

 
  if (OpenExcel.Exists)
 {
   OpenExcel.Close()
   Log.Message("Excels are taken care")
   aqUtils.Delay(3000)
 }
 else
 {
  Log.Message("Excels are taken care") 
 }
 
 
 
}














function EventControlWeb_OnStopTest(Sender)
{
  Log.Message("Last line of the Test")
  Log.Message("Generate Reports")
}
﻿

function MyLogs()

{
  URL = "www.Lufthanase.com"
  
Log.Message("Abd")

Log.Warning("Recheck")
Log.Link( URL, "DevURL")
Log.Error("Failure")

  

Log.Picture()


}
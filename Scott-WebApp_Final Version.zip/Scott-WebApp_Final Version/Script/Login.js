﻿//@AllTests
//@AppFunctions

function LaunchmyApp(){
  
  
Browsers.Item("iexplore").Run()
Browsers.Item("iexplore").Navigate("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx")

}



function Login(){
  

Aliases.browser.WebOrderPage.Login_UserName.SetText(Project.Variables.Username)
Aliases.browser.WebOrderPage.Login_Password.SetText("test")
NameMapping.Sys.browser.WebOrderPage.formAspnetform.Login_Submit.ClickButton()
}


function NavigateToOrder(){
Aliases.browser.OrderSummaryPage.CreateOrder.Click()
}







module.exports.LaunchmyApp = LaunchmyApp;
module.exports.Login = Login;
module.exports.NavigateToOrder = NavigateToOrder;
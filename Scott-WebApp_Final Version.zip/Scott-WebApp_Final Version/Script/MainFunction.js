﻿//USEUNIT ApplicationFunctions
function DataDrivenUsingDDT ()
{



DDT.ExcelDriver("D:\\Customer\Scott AirForce base\\TestComplete Projects\\Scott-WebApp\\WebOrder-UserDetails.xlsx", "Sheet1")

while (!DDT.CurrentDriver.EOF())
  {
    Log.AppendFolder("Login Validation")  
    Log.Message("User : " +DDT.CurrentDriver.Value(0));
    Log.Message("Password: " +DDT.CurrentDriver.Value(1))
    
                WebOrder_UserName = DDT.CurrentDriver.Value(0)
                WebOrder_Password = DDT.CurrentDriver.Value(1)
                
                
              
                
                
  LaunchmyApp()
  Login(WebOrder_UserName,WebOrder_Password)
  
  aqUtils.Delay(3000)
  
                if (Aliases.browser.OrderSummaryPage.table.cell.UserProfile.Exists)
                {
                  Log.Checkpoint("Valid User")
                }
                else
                {
                  Log.Warning("Invalid USer")
                }

 CloseApp()
 Log.PopLogFolder()  
 aqUtils.Delay(3000)
 
 
 DDT.CurrentDriver.Next();
 }
  
  DDT.CloseDriver(DDT.CurrentDriver.Name);
}

﻿function testcase1(){
  try{
  
LaunchmyApp1()

throw Error()
LaunchmyApp2()


}
catch (e)
{
  
Log.message ("Inside Main - Catch block")
}
}


function LaunchmyApp1(){
  
  try
  {

Browsers.Item("chrome").Run()

Browsers.Item("chrome").Navigate("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx")
Aliases.browser.WebOrderPage.Login_UserName.SetText("john")
Aliases.browser.WebOrderPage.Login_Password.SetText("test")
throw Error()
NameMapping.Sys.browser.WebOrderPage.formAspnetform.Login_Submit.ClickButton()
Aliases.browser.OrderSummaryPage.CreateOrder.Click()
}
catch(e)


{

Log.Warning("App 1 - Inside catch block")
}
}

function LaunchmyApp2(){
  
  try{
    

Browsers.Item("chrome").Run()
throw Error()
Browsers.Item("chrome").Navigate("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx")
Aliases.browser.WebOrderPage.Login_UserName.SetText(Project.Variables.Username)
Aliases.browser.WebOrderPage.Login_Password.SetText("test")
NameMapping.Sys.browser.WebOrderPage.formAspnetform.Login_Submit.ClickButton()
Aliases.browser.OrderSummaryPage.CreateOrder.Click()
}
catch(e)
{
  
Log.Warning("App 2 - Catch block")
}

}

﻿
function CreateOrdersFunction()
{  
Aliases.browser.pageWebOrders.formAspnetform.CreateOrders.Product.ClickItem("ScreenSaver")
Aliases.browser.pageWebOrders.formAspnetform.CreateOrders.MyQuantity.SetText("8")
}

















//Aliases.browser.pageWebOrders.formAspnetform.CreateOrders.Product.ClickItem("MyMoney")
//Aliases.browser.pageWebOrders.formAspnetform.CreateOrders.Product.ClickItem("FamilyAlbum")
//
//Log.message (Aliases.browser.pageWebOrders.formAspnetform.CreateOrders.Quantity.Text)
//
//if (Aliases.browser.pageWebOrders.formAspnetform.CreateOrders.Quantity.Text == 10) 
//
//{
//  Log.Message("RightValue")
//
//
//}
//else
//{
//Log.Error("Not entered the right value")  
//
//}

module.exports.CreateOrders = CreateOrders;
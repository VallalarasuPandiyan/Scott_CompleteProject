﻿function DataDrivenUsingDDT ()
{
Driver_User = DDT.ExcelDriver("D:\\Customer\\Scott AirForce base\\TestDataCusomters.xlsx", "Names")
while (!Driver_User.EOF())
  {
    WebOrders_Username = Driver_User.Value(0)
    WebORders_PAssword =Driver_User.Value(1)
    Log.Message("CurrentUser: " + WebOrders_Username)     
                                  
                                    Driver_Scenario = DDT.ExcelDriver("D:\\Customer\\Scott AirForce base\\TestDataCusomters.xlsx", "Products")
                                     while (!Driver_Scenario.EOF())
                                      {                                      
                                       WebOrders_Scenario = Driver_Scenario.Value(0)
                                       Log.AppendFolder("Scenario")
                                       Log.Message("Current Scenario: " + WebOrders_Scenario)
                                       Log.PopLogFolder()
                                       Driver_Scenario.Next();
                                      }
                                     DDT.CloseDriver(Driver_Scenario.Name);
    Driver_User.Next();
  }
DDT.CloseDriver(Driver_User.Name);
}
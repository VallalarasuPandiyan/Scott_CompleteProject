﻿

function Wb_Textbox(TextObject,Input)
{
  
TextObject.SetText(Input)

}



function LaunchmyApp(){
Browsers.Item("chrome").Run()
Browsers.Item("chrome").Navigate("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx")
}

function Login()
{
  //Object Paramaerizing
  //Data Parametirzing 
O_Uname = Aliases.browser.WebOrderPage.Login_UserName
O_Pwd = Aliases.browser.WebOrderPage.Login_Password
O_Quantity = Aliases.browser.pageWebOrders.formAspnetform.CreateOrders.MyQuantity
O_Price = Aliases.browser.pageWebOrders.formAspnetform.CreateOrders.textboxPricePerUnit
O_CustomerName = Aliases.browser.pageWebOrders.formAspnetform.CreateOrders.textboxCustomerName


LaunchmyApp()


Wb_Textbox(O_Uname,"Tester")
Wb_Textbox(O_Pwd,"test")
NameMapping.Sys.browser.WebOrderPage.formAspnetform.Login_Submit.ClickButton()

Aliases.browser.OrderSummaryPage.CreateOrder.Click()
Aliases.browser.pageWebOrders.formAspnetform.CreateOrders.Product.ClickItem("ScreenSaver")


Wb_Textbox(O_Quantity,5)
Wb_Textbox(O_Price,15)
Wb_Textbox(O_CustomerName,"Valla")

}Aliases.browser.pageWebOrders.formAspnetform.CreateOrders.Product.ClickItem("ScreenSaver")
Aliases.browser.pageWebOrders.formAspnetform.CreateOrders.MyQuantity.SetText("8")


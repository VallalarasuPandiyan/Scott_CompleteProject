﻿

//USEUNIT ApplicationFunctions
function DataDrivenbyVar()

{
  



  LaunchmyApp()
  Login(Uname,Pwd)
  CloseApp()
aqUtils.Delay(3000)  




}

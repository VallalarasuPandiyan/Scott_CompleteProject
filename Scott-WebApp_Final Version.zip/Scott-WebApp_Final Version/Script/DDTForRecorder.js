﻿function Test1()
{
  
DDT.ExcelDriver("D:\\Customer\\Scott AirForce base\\TestComplete Projects\\Scott-WebApp\\WebOrder-UserDetails.xlsx", "Sheet1")
while (!DDT.CurrentDriver.EOF())
  {
    WebOrders_Username = DDT.CurrentDriver.Value(0)
    WebORders_PAssword =DDT.CurrentDriver.Value(1)

  let browser = Aliases.browser;
  let browserWindow = browser.BrowserWindow;
  
  Browsers.Item("Chrome").Run()
  Browsers.Item(btChrome).Navigate("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx");
  let page = browser.WebOrderPage;
  let textbox = page.Login_UserName;
  textbox.Click();
  textbox.SetText(WebOrders_Username);
  page.Login_Password.SetText(WebORders_PAssword);
  page.Login_Submit.ClickButton();
  page = browser.OrderSummaryPage;
 
  if (Aliases.browser.OrderSummaryPage.table.cell.UserProfile.Exists)
  {
    
  Log.Message("Validation: Valid UserNAme")
 
  }
  else
  {
    
  Log.Message("Invalid USername ")
  }

  
  browserWindow.Close();

  DDT.CurrentDriver.Next();
  }
  DDT.CloseDriver(DDT.CurrentDriver.Name);


}




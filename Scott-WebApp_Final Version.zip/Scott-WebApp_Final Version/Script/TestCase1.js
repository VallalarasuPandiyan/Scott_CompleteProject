﻿//USEUNIT Login
//USEUNIT CreateOrders
//USEUNIT MathsFormula
function Testcase1()
{
LaunchmyApp()
Login.Login()
Login.NavigateToOrder()
aqUtils.Delay(2000)
CreateOrdersFunction()
MathsFormula.Sum()
Divide()
subtract()
MathsFormula.Multiple()
MathsFormula.sum()
}

function CheckboxIdentity(CustomerName)
{
RowIdentifier = Sys.Browser("iexplore").FindChild(Array("ObjectType","contentText"),Array("Cell",CustomerName),30)
Log.Message(RowIdentifier.ColumnIndex)
Log.Message(RowIdentifier.RowIndex)
Log.Picture(RowIdentifier,CustomerName)


WebTable =  Sys.Browser("iexplore").FindChild("ObjectIdentifier","orderGrid",30)
CheckboxElement = WebTable.Cell(RowIdentifier.RowIndex,RowIdentifier.ColumnIndex-1)


CheckboxElement.Click()
}


function SetMultipleCheckbox()
{
  //DataParamertisation
  CheckboxIdentity("Steve Johns")
  
  CheckboxIdentity("Samuel Clemens")
  CheckboxIdentity("Mark Smith")
  
  //External files - DataDriven
  
   //CheckboxIdentity(Excel.cell(1,1))
  
 
  }


  function XpathIdentification()
  {
    
  //Xpath_UserName = Sys.Browser("iexplore").Page("*")
  
 Xpath_UserName=  Sys.Browser("iexplore").Page("http://secure.smartbearsoftware.com/samples/TestComplete11/WebOrders/Login.aspx?ReturnUrl=%2fsamples%2fTestComplete11%2fWebOrders%2fdefault.aspx").FindChildByXPath("//*[@id='ctl00_MainContent_username']")
  
  Xpath_UserName.SetText("XpathUname")
  NewXpath = Aliases.browser.pageWebOrders.FindChildByXPath("//*[@id='ctl00_MainContent_username']")
  NewXpath.SetText("SuperTester")
  }
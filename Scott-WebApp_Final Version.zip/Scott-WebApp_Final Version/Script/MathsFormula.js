﻿function Sum()
{
  
c = a+b
}

function Multiple(){
  
d= a*b

}

function Divide(){
  
e=a/b
}

function subtract()

{
f = a- b  

}

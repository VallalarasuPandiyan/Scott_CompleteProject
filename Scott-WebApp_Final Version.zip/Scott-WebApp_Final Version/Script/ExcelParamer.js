﻿

function ReadExcelSheet(fname, sheetName,RowNum, ColNum)
{
var app = Sys.OleObject("Excel.Application");
var book = app.Workbooks.Open(fname);
var sheet = book.Sheets.Item(sheetName)
app.DisplayAlerts = false;
Log.Message(sheet.Cells.Item(RowNum,ColNum))
return sheet.Cells.Item(RowNum,ColNum)
book.Save();
app.Quit();
}

function TestData()
{
  
MyValue = ReadExcelSheet("D:\\Customer\\Scott AirForce base\\TestDataProducts.xlsx","MyProducts",1,3)
Log.Message(MyValue)
}

function ExcelReading_Implemented()
{

fname = "D:\\Customer\\Scott AirForce base\\TestData2.xlsx"
var sheetName ="MyProducts";
var MySetofRows= 3;
var MySetofColums = 2;
ReadExcelSheet(fname, sheetName,MySetofRows,MySetofColums)
}


//
//function ReadCompleteExcel()
//{
//
//Sample_Excel = ExternalSourcePath + “SampleExcel.xlsx”
//var s = "";
//
//let Excel = getActiveXObject(“Excel.Application”);
//Excel.Workbooks.Open(Sample_Excel);
//
//let RowCount = Excel.ActiveSheet.UsedRange.Rows.Count;
//let ColumnCount = Excel.ActiveSheet.UsedRange.Columns.Count;
//
//Log.Message(Sample_Excel)
//Log.Message(RowCount)
//Log.Message(ColumnCount)
//
//for ( i = 1; i <= RowCount; i++)
//{
//
//C1 = (VarToString(Excel.Cells.Item(i, 1)) + “\r\n”);
//C2 = (VarToString(Excel.Cells.Item(i, 2)) + “\r\n”);
//C3 = (VarToString(Excel.Cells.Item(i, 3)) + “\r\n”);
//C2 = (VarToString(Excel.Cells.Item(i, 4)) + “\r\n”);
//
//
//Log.Message(i +”,”+ j + “Value: ” + s)
//}
//}
//
//Excel.Quit();
//}
//

